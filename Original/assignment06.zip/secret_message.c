/*
Compile: make secret_message
Run: ./secret_message
*/

#include "base.h"

//todo: Write decode method

//todo: Write test method for decode

//todo: Write encode method

//todo: Write test method for encode

int main(void){
	//todo: Decode this message to get a hint for part c) + d)
	String secret_message = "Kiltiznnrvivm 1 nzxsg Hkzhh. Wrvh rhg pvrmv Dviyfmt ufvi vgdzrtv Kilwfpgv zfu wvn Yrow. Grkk: Wrv Olvhfmt ufvi wzh vmxlwrvivm rhg tzma vrmuzxs fmw kzhhg rm vrmv Avrov.";
	
	//printsln(decode(secret_message));
	//printsln(encode(decode(secret_message)));
	
	//call test functions

	return 0;
}