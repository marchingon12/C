/*
Compile: make total-solution
Run: ./total-solution
make total-solution && ./total-solution
*/

#include "base.h"


//todo: define constants 



//todo: Write function total



//todo: Write function total_test


int main (void){

	//todo: call total_test Function
}