/*
Compile: make people
Run: ./people
*/

#include "base.h"
#include "string.h"

// a) struct Statistics ...

// b) ... make_statistics...

// c) ... print_statistics...

// d) ... compute_statistics...


int main(void) {
	String table = s_read_file("people.txt");
	printsln(table);
	// ... compute_statistics(table);
	// print_statistics(...);
	return 0;
}
